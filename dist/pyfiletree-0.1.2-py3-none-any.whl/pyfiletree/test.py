import library


def func1():
    x = 0
    if x == 0:
        print("hehe")
    return x
y = 0


class HI:
    Available = 0

    def __str__(self):
        return 'de ce nu?'
